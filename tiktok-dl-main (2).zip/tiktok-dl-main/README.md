### tiktok-dl

Simple tiktok downloader

### Screenshots
<img src="demo.png"/>

### Build with
- Bootstrap 4
- Font awesome
- Flask

### Demo
<b>https://tiktok-download.herokuapp.com/</b>
